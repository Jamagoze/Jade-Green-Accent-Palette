# Emerald Green LSPosed module

Minimal LSPosed module. Package: `com.jama.eg`.

It hooks `WallpaperColors.getPrimaryColor()` inside System UI and returns
Emerald Green (`#00A86B`) as the wallpaper primary color used by the
Android Monet color pipeline.

No launcher activity, UI, services, or background process.

Build output: `app/build/outputs/apk/release/app-release.apk`

Enable the module in LSPosed and select System UI (`com.android.systemui`)
as its scope, then reboot.
