package com.jama.eg;

import android.graphics.Color;
import android.app.WallpaperColors;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class EmeraldHook implements IXposedHookLoadPackage {
    private static final Color EMERALD = Color.valueOf(0xFF00A86B);

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"com.android.systemui".equals(lpparam.packageName)) return;

        try {
            XposedHelpers.findAndHookMethod(
                WallpaperColors.class,
                "getPrimaryColor",
                new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        param.setResult(EMERALD);
                    }
                }
            );
            XposedBridge.log("Emerald Green: Monet seed override active.");
        } catch (Throwable t) {
            XposedBridge.log("Emerald Green: hook failed: " + t);
        }
    }
}
