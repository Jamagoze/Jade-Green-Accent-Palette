#!/system/bin/sh
until [ "$(getprop sys.boot_completed)" = 1 ];do sleep 3;done
sleep 5
C=00A86B
settings put secure theme_customization_overlay_packages "{\"android.theme.customization.system_palette\":\"$C\",\"android.theme.customization.accent_color\":\"$C\",\"android.theme.customization.color_source\":\"preset\",\"android.theme.customization.theme_style\":\"TONAL_SPOT\"}"
