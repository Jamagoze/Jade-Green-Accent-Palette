# Emerald Monet — LSPosed module

For Android 14 / API 34. Forces the Android SystemUI Monet seed color to
Emerald Green (`#00A86B`) so SystemUI generates a green dynamic palette.

## Build

This project is built by GitHub Actions using JDK 17 and Gradle 8.7.
The APK output is `app/build/outputs/apk/debug/app-debug.apk`.

## Install and activate

1. Install the generated APK.
2. Open LSPosed and enable **Emerald Monet**.
3. In module scope, select **System UI** (`com.android.systemui`).
4. Reboot the device (or restart System UI).
5. If the palette does not refresh, change the wallpaper once and reboot.

## Notes

- The hook changes the accent and neutral seed colors returned by
  `ThemeOverlayController` while SystemUI processes wallpaper colors.
- Apps using Android dynamic color / Monet overlays should inherit the palette.
- Apps with hard-coded colors or their own theme engines may not change.
- HyperOS may rename or alter internal SystemUI classes. If its
  `ThemeOverlayController` differs from AOSP Android 14, the hook may not attach.
- This module does not modify system partitions and can be disabled in LSPosed.
