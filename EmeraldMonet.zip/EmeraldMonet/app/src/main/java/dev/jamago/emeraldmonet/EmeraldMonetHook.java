package dev.jamago.emeraldmonet;

import android.app.WallpaperColors;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class EmeraldMonetHook implements IXposedHookLoadPackage {
    private static final int EMERALD_GREEN = 0xFF00A86B;
    private static final String TAG = "EmeraldMonet";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"com.android.systemui".equals(lpparam.packageName)) {
            return;
        }

        try {
            Class<?> controller = XposedHelpers.findClass(
                "com.android.systemui.theme.ThemeOverlayController",
                lpparam.classLoader
            );

            hookSeedMethod(controller, "getAccentColor");
            hookSeedMethod(controller, "getNeutralColor");

            XposedBridge.log(TAG + ": emerald Monet hooks installed in SystemUI");
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": failed to hook ThemeOverlayController: " + t);
        }
    }

    private static void hookSeedMethod(Class<?> controller, String methodName) {
        try {
            XposedHelpers.findAndHookMethod(
                controller,
                methodName,
                WallpaperColors.class,
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        param.setResult(EMERALD_GREEN);
                    }
                }
            );
            XposedBridge.log(TAG + ": hooked " + methodName);
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": could not hook " + methodName + ": " + t);
        }
    }
}
