package dev.jamago.emeraldmonet;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(28, 32, 28, 32);
        root.setBackgroundColor(Color.rgb(12, 24, 19));

        TextView title = new TextView(this);
        title.setText("Emerald Monet");
        title.setTextColor(Color.rgb(0, 200, 130));
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);

        TextView info = new TextView(this);
        info.setText(
            "LSPosed module\n\n" +
            "Seed color: #00A86B (Emerald Green)\n\n" +
            "Enable this module in LSPosed and enable its scope for System UI " +
            "(com.android.systemui). Then reboot or restart System UI.\n\n" +
            "The module changes the seed used by Android Monet when System UI " +
            "generates dynamic color overlays. Apps that support Android dynamic " +
            "colors should follow the emerald palette. Apps with fixed/custom " +
            "colors may not change.\n\n" +
            "If the theme does not update immediately, change the wallpaper once " +
            "or reboot the device."
        );
        info.setTextColor(Color.rgb(225, 239, 231));
        info.setTextSize(16);
        info.setGravity(Gravity.CENTER);
        info.setPadding(0, 24, 0, 0);

        root.addView(title);
        root.addView(info);
        setContentView(root);
    }
}
